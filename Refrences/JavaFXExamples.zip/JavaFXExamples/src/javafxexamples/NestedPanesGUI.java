package javafxexamples;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.stage.Stage;

/**
 *
 * @author McKillaGorilla
 */
public class NestedPanesGUI extends Application {
    @Override
    public void start(Stage primaryStage) {

    }
    public static void main(String[] args) {
        launch(args);
    }
}
