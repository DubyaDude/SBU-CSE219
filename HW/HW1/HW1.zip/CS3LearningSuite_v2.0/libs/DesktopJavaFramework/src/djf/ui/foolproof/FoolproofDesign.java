package djf.ui.foolproof;

/**
 *
 * @author McKillaGorilla
 */
public interface FoolproofDesign {
    public void updateControls();
}
